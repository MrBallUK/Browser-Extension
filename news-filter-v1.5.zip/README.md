# Positive News Filter Chrome Extension

This Chrome extension filters out negative or sad articles from Sky News and BBC News websites. It helps create a more positive browsing experience by hiding articles that contain negative keywords.

## Features

- Automatically hides articles containing negative keywords
- Works on Sky News and BBC News websites
- Shows a brief notification when active
- Updates dynamically as you scroll or new content loads

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" in the top right corner
3. Click "Load unpacked" and select the extension directory
4. The extension will automatically start working when you visit Sky News or BBC News websites

## How it Works

The extension scans article headlines for negative keywords and hides articles that contain these words. It works continuously as you browse, filtering both initial content and dynamically loaded articles.

## Supported Websites

- Sky News (www.skynews.com, news.sky.com)
- BBC News (www.bbc.com/news, www.bbc.co.uk/news)

## Version

1.0 - Initial release
