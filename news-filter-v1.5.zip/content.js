// Default keywords organized by category
const DEFAULT_KEYWORDS = {
    violence: [
        'murder', 'killed', 'attack', 'terror', 'shooting', 'gunman', 'gunmen', 'armed',
        'violence', 'rape', 'raped', 'victim', 'massacre'
    ],
    death: [
        'death', 'died', 'dead', 'fatal', 'suicide', 'dies'
    ],
    disaster: [
        'crash', 'accident', 'emergency', 'disaster', 'crisis', 'catastrophe', 'tragedy',
        'tragic', 'sinks', 'crashes', 'panic', 'tsunami'
    ],
    politics: [
        'trump', 'politics', 'putin', 'scandal', 'russia', 'russian', 'syria', 'syrian'
    ],
    health: [
        'hospital', 'disease', 'virus', 'infection', 'outbreak', 'pandemic', 'epidemic'
    ],
    crime: [
        'jail', 'arrest', 'criminal', 'prison', 'villain', 'crime'
    ]
};

// Initialize variables
let currentKeywords = [];

// Load settings and start processing
function loadSettings() {
    chrome.storage.sync.get(['blockedKeywords', 'enabledCategories'], (data) => {
        console.log('Initial storage data:', data);
        
        // If no keywords are stored, initialize with defaults
        if (!data.blockedKeywords || Object.keys(data.blockedKeywords).length === 0) {
            console.log('No keywords found, initializing defaults');
            chrome.storage.sync.set({
                blockedKeywords: DEFAULT_KEYWORDS,
                enabledCategories: Object.keys(DEFAULT_KEYWORDS)
            }, () => {
                loadSettings();
            });
        } else {
            const categories = data.blockedKeywords || DEFAULT_KEYWORDS;
            const enabledCategories = data.enabledCategories || Object.keys(categories);
            
            // Flatten enabled categories into a single array of keywords
            currentKeywords = enabledCategories.reduce((acc, category) => {
                if (categories[category]) {
                    acc.push(...categories[category]);
                }
                return acc;
            }, []);

            console.log('Current keywords:', currentKeywords);
        }
    });
}

// Listen for changes in storage
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && (changes.blockedKeywords || changes.enabledCategories)) {
        console.log('Settings changed:', changes);
        loadSettings();
    }
});

// Add event listeners for page load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(processPage, 1000); // Initial process after 1 second
});

window.addEventListener('load', () => {
    setTimeout(processPage, 2000); // Process again after full load
});

// Process the page content
function processPage() {
    if (!currentKeywords || currentKeywords.length === 0) {
        console.log('No keywords available, skipping processing');
        return;
    }
    
    console.log('Processing page with keywords:', currentKeywords);

    // Use simpler, more universal selectors
    const selectors = [
        // Main content selectors
        'article',
        '[role="article"]',
        '.article',
        '.story',
        
        // Text content selectors
        'p',
        '.text',
        '.content',
        
        // Headline selectors
        'h1',
        'h2',
        'h3',
        '.headline',
        '.title',
        
        // News-specific selectors
        '[data-component="text-block"]',
        '.article-body',
        '.story-body',
        '.article-content',
        '.story-content'
    ].join(',');

    const elements = document.querySelectorAll(selectors);
    console.log('Found elements to check:', elements.length);
    
    elements.forEach((element, index) => {
        // Skip if already processed
        if (element.closest('.positive-news-replacement') || 
            element.hasAttribute('data-processed') ||
            element.closest('.positive-news-replacement')) {
            return;
        }

        // Skip navigation, header, footer, and menu elements
        if (element.closest('nav, header, footer, .navigation, .menu, aside, [role="navigation"], [role="complementary"]')) {
            return;
        }

        // Get text content
        const text = element.textContent.trim();
        if (!text || text.length < 15) { // Increased minimum length
            return;
        }

        // Check if element is visible
        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            return;
        }

        console.log(`Checking element ${index}:`, {
            tag: element.tagName,
            classes: element.className,
            text: text.substring(0, 100) + '...' // Log first 100 chars
        });

        // Check for keywords
        for (const keyword of currentKeywords) {
            const keywordLower = keyword.toLowerCase();
            const textLower = text.toLowerCase();
            
            // Use word boundaries for whole word matching
            const regex = new RegExp(`\\b${keywordLower}\\b`, 'i');
            
            if (regex.test(textLower)) {
                console.log('Found keyword match:', {
                    keyword: keyword,
                    elementType: element.tagName,
                    elementClass: element.className
                });
                
                replaceContent(element);
                element.setAttribute('data-processed', 'true');
                break;
            }
        }
    });

    // Set up observer for dynamic content
    setupMutationObserver();
}

// Function to replace content
function replaceContent(element) {
    try {
        // Store original content
        const originalContent = element.innerHTML;
        element.setAttribute('data-original-content', originalContent);
        
        const joke = getRandomDadJoke();
        const colors = getThemeColors();
        console.log('Replacing content with joke:', joke);

        // Create wrapper with preserved styling
        const wrapper = document.createElement('div');
        wrapper.className = 'positive-news-replacement';
        
        // Get original styles
        const computedStyle = window.getComputedStyle(element);
        wrapper.style.cssText = `
            font-family: ${computedStyle.fontFamily};
            font-size: ${computedStyle.fontSize};
            line-height: ${computedStyle.lineHeight};
            background: ${colors.background};
            color: ${colors.text};
            border-radius: 4px;
            box-shadow: 0 1px 3px ${colors.shadow};
            padding: 16px;
            margin: 12px 0;
            transition: all 0.2s ease;
            position: relative;
            border: 1px solid ${colors.border};
        `;
        
        // Add metadata bar (timestamp and category)
        const metaBar = document.createElement('div');
        metaBar.style.cssText = `
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
            font-size: 0.85em;
            color: ${colors.textSecondary};
        `;
        
        const timestamp = document.createElement('span');
        timestamp.textContent = 'Just now';
        
        const category = document.createElement('span');
        category.textContent = 'Positive Swap';
        category.style.color = colors.accent;
        
        metaBar.appendChild(timestamp);
        metaBar.appendChild(category);
        wrapper.appendChild(metaBar);
        
        // Add joke content
        const jokeTitle = document.createElement('h3');
        jokeTitle.style.cssText = `
            font-size: 1.2em;
            font-weight: 600;
            margin: 0 0 12px 0;
            color: ${colors.text};
            line-height: 1.3;
        `;
        jokeTitle.textContent = joke.title;
        
        const jokeDesc = document.createElement('p');
        jokeDesc.style.cssText = `
            font-size: 1em;
            line-height: 1.5;
            color: ${colors.textSecondary};
            margin: 0;
        `;
        jokeDesc.textContent = joke.description;
        
        // Add content to wrapper
        wrapper.appendChild(jokeTitle);
        wrapper.appendChild(jokeDesc);
        
        // Add subtle indicator
        const indicator = document.createElement('div');
        indicator.style.cssText = `
            position: absolute;
            top: 16px;
            right: 16px;
            font-size: 11px;
            color: ${colors.accent};
            display: flex;
            align-items: center;
            gap: 4px;
        `;
        
        const sparkleIcon = document.createElement('span');
        sparkleIcon.textContent = '✨';
        sparkleIcon.style.fontSize = '14px';
        
        const indicatorText = document.createElement('span');
        indicatorText.textContent = 'Stay Happy';
        
        indicator.appendChild(sparkleIcon);
        indicator.appendChild(indicatorText);
        wrapper.appendChild(indicator);
        
        // Replace content
        element.innerHTML = '';
        element.appendChild(wrapper);
        
        // Add hover effect
        wrapper.addEventListener('mouseover', () => {
            wrapper.style.transform = 'translateY(-1px)';
            wrapper.style.boxShadow = `0 4px 6px ${colors.shadow}`;
        });
        
        wrapper.addEventListener('mouseout', () => {
            wrapper.style.transform = 'none';
            wrapper.style.boxShadow = `0 1px 3px ${colors.shadow}`;
        });

        // Listen for system color scheme changes
        const colorSchemeQuery = window.matchMedia('(prefers-color-scheme: dark)');
        colorSchemeQuery.addListener(() => {
            const newColors = getThemeColors();
            wrapper.style.background = newColors.background;
            wrapper.style.color = newColors.text;
            wrapper.style.borderColor = newColors.border;
            wrapper.style.boxShadow = `0 1px 3px ${newColors.shadow}`;
            jokeTitle.style.color = newColors.text;
            jokeDesc.style.color = newColors.textSecondary;
            metaBar.style.color = newColors.textSecondary;
            indicator.style.color = newColors.accent;
        });
        
        console.log('Content replaced successfully');
    } catch (error) {
        console.error('Error replacing content:', error);
        // Restore original content if replacement fails
        if (element.hasAttribute('data-original-content')) {
            element.innerHTML = element.getAttribute('data-original-content');
        }
    }
}

// Function to get color scheme
function isDarkMode() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}

// Function to get theme colors
function getThemeColors() {
    const isDark = isDarkMode();
    return {
        background: isDark ? '#1a1a1a' : '#ffffff',
        text: isDark ? '#e0e0e0' : '#1a1a1a',
        textSecondary: isDark ? '#a0a0a0' : '#666666',
        accent: '#28a745',
        shadow: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(0,0,0,0.1)',
        border: isDark ? '#333333' : '#e0e0e0'
    };
}

// Set up mutation observer for dynamic content
function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1 && // Element node
                    !node.closest('.positive-news-replacement') &&
                    !node.hasAttribute('data-processed')) {
                    
                    // Check if it's a text-containing element
                    if (node.matches('p, h1, h2, h3, article p, .article-body p')) {
                        const text = node.textContent.trim();
                        if (!text || text.length < 10) return;

                        console.log('Checking dynamic content:', text);

                        for (const keyword of currentKeywords) {
                            const regex = new RegExp(`\\b${keyword.toLowerCase()}\\b`, 'i');
                            if (regex.test(text.toLowerCase())) {
                                console.log('Found keyword in dynamic content:', keyword);
                                replaceContent(node);
                                node.setAttribute('data-processed', 'true');
                                break;
                            }
                        }
                    }
                }
            });
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// Collection of dad jokes
const dadJokes = [
    {
        title: "What do you call a bear with no teeth?",
        description: "A gummy bear!",
        image: "https://images.unsplash.com/photo-1590418606746-018840f9cd0f?w=300"
    },
    {
        title: "Why don't eggs tell jokes?",
        description: "They'd crack up!",
        image: "https://images.unsplash.com/photo-1607690424560-958b243a7cb1?w=300"
    },
    {
        title: "What do you call a fake noodle?",
        description: "An impasta!",
        image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=300"
    },
    {
        title: "Why did the scarecrow win an award?",
        description: "Because he was outstanding in his field!",
        image: "https://images.unsplash.com/photo-1472190649224-0ec0c57515c7?w=300"
    },
    {
        title: "What do you call a pig that does karate?",
        description: "A pork chop!",
        image: "https://images.unsplash.com/photo-1592194996308-37b1b58a9fe7?w=300"
    },
    {
        title: "What do you call a can opener that doesn't work?",
        description: "A can't opener!",
        image: "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=300"
    },
    {
        title: "Why did the cookie go to the doctor?",
        description: "Because it was feeling crumbly!",
        image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=300"
    },
    {
        title: "What did the grape say when it got stepped on?",
        description: "Nothing, it just let out a little wine!",
        image: "https://images.unsplash.com/photo-1596363505729-4190a9506133?w=300"
    },
    {
        title: "Why don't math books tell jokes?",
        description: "Because their problems are too hard!",
        image: "https://images.unsplash.com/photo-1635372722656-389f87a941b7?w=300"
    },
    {
        title: "What do you call a sleeping bull?",
        description: "A bulldozer!",
        image: "https://images.unsplash.com/photo-1599491286120-a965c607e146?w=300"
    },
    {
        title: "Why did the golfer bring two pairs of pants?",
        description: "In case he got a hole in one!",
        image: "https://images.unsplash.com/photo-1535131749006-b7c4a6e09661?w=300"
    },
    {
        title: "What do you call a fish wearing a crown?",
        description: "A kingfish!",
        image: "https://images.unsplash.com/photo-1524704796725-9fc3044a58b2?w=300"
    },
    {
        title: "Why don't scientists trust atoms?",
        description: "Because they make up everything!",
        image: "https://images.unsplash.com/photo-1628595351029-c2bf17511435?w=300"
    },
    {
        title: "What do you call a snowman with a six-pack?",
        description: "An abdominal snowman!",
        image: "https://images.unsplash.com/photo-1607250886762-958b243a7cb1?w=300"
    },
    {
        title: "Why did the bicycle fall over?",
        description: "Because it was two-tired!",
        image: "https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?w=300"
    }
];

// Function to get a random dad joke
function getRandomDadJoke() {
    const randomIndex = Math.floor(Math.random() * dadJokes.length);
    return dadJokes[randomIndex];
}

// Function to create the replacement content
function createReplacementContent(joke) {
    const wrapper = document.createElement('div');
    wrapper.className = 'positive-news-replacement';
    wrapper.style.padding = '15px';
    wrapper.style.margin = '10px 0';
    wrapper.style.borderRadius = '8px';
    wrapper.style.backgroundColor = isDarkMode() ? '#2c3e50' : '#f8f9fa';
    wrapper.style.color = isDarkMode() ? '#ecf0f1' : '#2c3e50';
    wrapper.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
    wrapper.style.transition = 'all 0.3s ease';

    const imageContainer = document.createElement('div');
    imageContainer.style.marginBottom = '10px';
    imageContainer.style.borderRadius = '4px';
    imageContainer.style.overflow = 'hidden';
    imageContainer.style.maxWidth = '300px';
    imageContainer.style.margin = '0 auto';

    const image = document.createElement('img');
    image.src = joke.image;
    image.alt = joke.title;
    image.style.width = '100%';
    image.style.height = 'auto';
    image.style.display = 'block';
    image.style.borderRadius = '4px';
    
    // Add error handling for images
    image.onerror = () => {
        console.log('Image failed to load:', joke.image);
        image.src = 'https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=300'; // Default fallback image
    };

    const title = document.createElement('h3');
    title.textContent = joke.title;
    title.style.margin = '10px 0';
    title.style.fontSize = '18px';
    title.style.fontWeight = 'bold';

    const description = document.createElement('p');
    description.textContent = joke.description;
    description.style.fontSize = '16px';
    description.style.margin = '5px 0';

    imageContainer.appendChild(image);
    wrapper.appendChild(imageContainer);
    wrapper.appendChild(title);
    wrapper.appendChild(description);

    return wrapper;
}

// Function to check if dark mode is enabled
function isDarkMode() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}

// Function to get theme colors based on dark/light mode
function getThemeColors() {
    const isDark = isDarkMode();
    return {
        cardBg: isDark ? '#2d2d2d' : '#ffffff',
        border: isDark ? '#404040' : '#e5e5e5',
        title: isDark ? '#ffffff' : '#1a1a1a',
        text: isDark ? '#e0e0e0' : '#4a4a4a',
        subtext: isDark ? '#a0a0a0' : '#666666'
    };
}

// Function to create a styled element with content
function createStyledElement(type, content = '', styles = {}) {
    const element = document.createElement(type);
    if (content) {
        element.textContent = content;
    }
    Object.assign(element.style, styles);
    return element;
}

// Function to create content container with theme support
function createContentContainer(title, description, image, source) {
    const colors = getThemeColors();
    const container = createStyledElement('div', '', {
        padding: '15px',
        background: colors.cardBg,
        borderRadius: '8px',
        margin: '10px 0',
        border: `1px solid ${colors.border}`,
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    });

    const titleElement = createStyledElement('h3', title, {
        color: colors.title,
        marginBottom: '10px',
        fontSize: '16px',
        lineHeight: '1.4'
    });
    container.appendChild(titleElement);

    const imgElement = document.createElement('img');
    imgElement.src = image;
    imgElement.alt = title;
    Object.assign(imgElement.style, {
        maxWidth: '300px',
        borderRadius: '4px',
        margin: '10px 0',
        width: '100%',
        height: 'auto'
    });
    container.appendChild(imgElement);

    const descElement = createStyledElement('p', description, {
        color: colors.text,
        fontSize: '14px',
        lineHeight: '1.5',
        margin: '10px 0'
    });
    container.appendChild(descElement);

    const sourceElement = createStyledElement('small', source, {
        color: colors.subtext,
        fontSize: '12px'
    });
    container.appendChild(sourceElement);

    return container;
}

// Watch for dark mode changes
const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
darkModeMediaQuery.addListener(() => {
    processPage();
});

// Start the initialization process
loadSettings();
