// Default keywords organized by category
const DEFAULT_KEYWORDS = {
    violence: [
        'murder', 'killed', 'attack', 'terror', 'shooting', 'gunman', 'gunmen', 'armed',
        'violence', 'rape', 'raped', 'victim', 'massacre'
    ],
    death: [
        'death', 'died', 'dead', 'fatal', 'suicide', 'dies'
    ],
    disaster: [
        'crash', 'accident', 'emergency', 'disaster', 'crisis', 'catastrophe', 'tragedy',
        'tragic', 'sinks', 'crashes', 'panic'
    ],
    politics: [
        'trump', 'politics', 'putin', 'scandal', 'russia', 'russian', 'syria', 'syrian'
    ],
    health: [
        'hospital', 'disease', 'virus', 'infection', 'outbreak', 'pandemic', 'epidemic'
    ],
    crime: [
        'jail', 'arrest', 'criminal', 'prison', 'villain', 'crime'
    ]
};

// Initialize extension settings
function initializeSettings() {
    chrome.storage.sync.get(['blockedKeywords', 'enabledCategories'], (data) => {
        const updates = {};
        let needsUpdate = false;

        // Initialize keywords if not set
        if (!data.blockedKeywords || Object.keys(data.blockedKeywords).length === 0) {
            updates.blockedKeywords = DEFAULT_KEYWORDS;
            needsUpdate = true;
        }

        // Initialize enabled categories if not set
        if (!data.enabledCategories || data.enabledCategories.length === 0) {
            updates.enabledCategories = Object.keys(DEFAULT_KEYWORDS);
            needsUpdate = true;
        }

        // Save updates if needed
        if (needsUpdate) {
            chrome.storage.sync.set(updates, () => {
                console.log('Settings initialized:', updates);
            });
        }
    });
}

// Handle extension installation and updates
chrome.runtime.onInstalled.addListener((details) => {
    console.log('Extension event:', details.reason);
    
    // Initialize on install or update
    if (details.reason === 'install' || details.reason === 'update') {
        initializeSettings();
    }
});

// Handle extension startup
chrome.runtime.onStartup.addListener(() => {
    console.log('Extension starting up');
    initializeSettings();
});
